<?php
session_start();
require_once 'function.php';

// Check for cookies if session is not set
if (!isset($_SESSION['seller_id']) && isset($_COOKIE['seller_id'])) {
    $_SESSION['seller_id'] = $_COOKIE['seller_id'];
}
if (!isset($_SESSION['stall_id']) && isset($_COOKIE['stall_id'])) {
    $_SESSION['stall_id'] = $_COOKIE['stall_id'];
}

if (!isset($_SESSION['stall_id'])) {
    echo "<div class='alert error'>Stall not found. Please log in again.</div>";
    exit;
}

// Handle product deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $product_id = intval($_GET['delete']);
    $conn = new mysqli("localhost", "root", "", "ezorderdb");
    $stmt = $conn->prepare("DELETE FROM products WHERE product_id = ? AND stall_id = ?");
    $stmt->bind_param("ii", $product_id, $_SESSION['stall_id']);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    echo "<div class='alert success'>Product deleted successfully!</div>";
}

// Handle product update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_product_id'])) {
    $product_id = intval($_POST['edit_product_id']);
    $product_name = $_POST['edit_product_name'];
    $price = $_POST['edit_price'];
    $description = $_POST['edit_description'];
    $product_path = $_POST['current_product_path'];
    $category = $_POST['edit_category'];

    // Handle new image upload
    if (isset($_FILES['edit_product_path']) && $_FILES['edit_product_path']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = "uploads/products/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $filename = basename($_FILES['edit_product_path']['name']);
        $product_path = $upload_dir . uniqid() . "_" . $filename;
        move_uploaded_file($_FILES['edit_product_path']['tmp_name'], $product_path);
    }

    $conn = new mysqli("localhost", "root", "", "ezorderdb");
    $stmt = $conn->prepare("UPDATE products SET product_name=?, price=?, product_path=?, description=?, category=? WHERE product_id=? AND stall_id=?");
    $stmt->bind_param("sdsssii", $product_name, $price, $product_path, $description, $category, $product_id, $_SESSION['stall_id']);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    echo "<div class='alert success'>Product updated successfully!</div>";
}

// Handle adding new products
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_products'])) {
    $stall_id = $_SESSION['stall_id'];
    foreach ($_POST['product_name'] as $i => $product_name) {
        $price = $_POST['price'][$i];
        $description = $_POST['description'][$i];
        $category = $_POST['category'][$i];

        // Handle product image upload
        $product_path = "";
        if (isset($_FILES['product_path']['name'][$i]) && $_FILES['product_path']['error'][$i] == UPLOAD_ERR_OK) {
            $upload_dir = "uploads/products/";
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $filename = basename($_FILES['product_path']['name'][$i]);
            $product_path = $upload_dir . uniqid() . "_" . $filename;
            move_uploaded_file($_FILES['product_path']['tmp_name'][$i], $product_path);
        }

        $conn = new mysqli("localhost", "root", "", "ezorderdb");
        $stmt = $conn->prepare("INSERT INTO products (product_name, stall_id, price, product_path, description, category) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sidsss", $product_name, $stall_id, $price, $product_path, $description, $category);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }
    echo "<div class='alert success'>Products added successfully!</div>";
}

if (isset($_GET['publish']) && is_numeric($_GET['publish'])) {
    $product_id = intval($_GET['publish']);
    $conn = new mysqli("localhost", "root", "", "ezorderdb");
    $stmt = $conn->prepare("UPDATE products SET is_featured = 1 WHERE product_id = ? AND stall_id = ?");
    $stmt->bind_param("ii", $product_id, $_SESSION['stall_id']);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    echo "<div class='alert success'>Product published (featured) successfully!</div>";
}
if (isset($_GET['unpublish']) && is_numeric($_GET['unpublish'])) {
    $product_id = intval($_GET['unpublish']);
    $conn = new mysqli("localhost", "root", "", "ezorderdb");
    $stmt = $conn->prepare("UPDATE products SET is_featured = 0 WHERE product_id = ? AND stall_id = ?");
    $stmt->bind_param("ii", $product_id, $_SESSION['stall_id']);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    echo "<div class='alert success'>Product unpublished successfully!</div>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Products - Kiosk Style</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700,400&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Montserrat', Arial, sans-serif;
            background: #f4f6fb;
        }
        .kiosk-container {
            max-width: 1100px;
            margin: 40px auto 0 auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.07);
            padding: 40px 32px 32px 32px;
        }
        h1, h2 {
            color: #ffb347;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 18px;
        }
        .product-form-section {
            background: #fffbe6;
            border-radius: 12px;
            padding: 24px 18px;
            margin-bottom: 32px;
            box-shadow: 0 2px 12px rgba(255,204,51,0.08);
        }
        .product-entry {
            display: flex;
            gap: 16px;
            align-items: flex-start;
            margin-bottom: 12px;
            flex-wrap: wrap;
        }
        .product-entry input[type="text"],
        .product-entry input[type="number"],
        .product-entry textarea {
            padding: 10px;
            border-radius: 7px;
            border: 1px solid #ffd966;
            font-size: 1em;
            width: 180px;
        }
        .product-entry textarea {
            width: 220px;
            height: 40px;
            resize: vertical;
        }
        .product-entry input[type="file"] {
            display: none;
        }
        .file-label {
            display: inline-block;
            background: linear-gradient(135deg, #ffb347 0%, #ffcc33 100%);
            color: #fff;
            border-radius: 7px;
            padding: 8px 18px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            margin-right: 8px;
            margin-top: 4px;
            transition: background 0.18s;
        }
        .file-label:hover {
            background: linear-gradient(135deg, #ffcc33 0%, #ffb347 100%);
        }
        .file-name {
            font-size: 0.95em;
            color: #b8860b;
            margin-left: 8px;
            vertical-align: middle;
        }
        .kiosk-btn, button[type="submit"] {
            background: linear-gradient(135deg, #ffb347 0%, #ffcc33 100%);
            color: #fff;
            border: none;
            border-radius: 7px;
            padding: 10px 22px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            margin-right: 8px;
            margin-top: 10px;
            transition: background 0.18s;
        }
        .kiosk-btn:hover, button[type="submit"]:hover {
            background: linear-gradient(135deg, #ffcc33 0%, #ffb347 100%);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 12px rgba(255,204,51,0.08);
        }
        th, td {
            padding: 14px 10px;
            text-align: center;
        }
        th {
            background: #ffedb3;
            color: #b8860b;
            font-size: 1.1em;
        }
        tr:nth-child(even) {
            background: #fffbe6;
        }
        tr:hover {
            background: #fff3cd;
        }
        img {
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(255,204,51,0.12);
        }
        .alert.success {
            background: #d4edda;
            color: #155724;
            border-radius: 7px;
            padding: 12px 18px;
            margin-bottom: 18px;
            border: 1px solid #c3e6cb;
        }
        @media (max-width: 900px) {
            .kiosk-container {
                padding: 10px 2vw;
            }
            .product-entry {
                flex-direction: column;
                gap: 8px;
            }
        }
    </style>
</head>
<body>
<div class="kiosk-container">
    <h1>Manage Products</h1>
    <div class="product-form-section">
        <form action="manage_products.php" method="post" enctype="multipart/form-data">
            <div id="products">
                <div class="product-entry">
                    <input type="text" name="product_name[]" placeholder="Product Name" required>
                    <input type="number" step="0.01" name="price[]" placeholder="Price" required>
                    <label class="file-label">
                        Choose Image
                        <input type="file" name="product_path[]" accept="image/*" onchange="showFileName(this)">
                    </label>
                    <span class="file-name"></span>
                    <textarea name="description[]" placeholder="Description"></textarea>
                    <select name="category[]" required>
                        <option value="">Select Category</option>
                        <option value="Beverages">Beverages</option>
                        <option value="Snacks">Snacks</option>
                        <option value="Meals">Meals</option>
                        <option value="Desserts">Desserts</option>
                    </select>
                </div>
            </div>
            <button type="button" class="kiosk-btn" onclick="addProduct()">Add Another Product</button>
            <button type="submit" class="kiosk-btn" name="add_products">Add Products</button>
        </form>
    </div>

    <h2>Your Products</h2>
    <table>
        <tr>
            <th>Product Name</th>
            <th>Price</th>
            <th>Image</th>
            <th>Description</th>
            <th>Category</th>
            <th>Available</th>
            <th>Actions</th>
        </tr>
        <?php
        // Display products for this stall
        if (isset($_SESSION['stall_id'])) {
            $stall_id = $_SESSION['stall_id'];
            $conn = new mysqli("localhost", "root", "", "ezorderdb");
            // Update the SELECT query to include category
            $stmt = $conn->prepare("SELECT product_id, product_name, price, product_path, description, is_featured, category FROM products WHERE stall_id = ?");
            $stmt->bind_param("i", $stall_id);
            $stmt->execute();
            // Update the bind_result line
            $stmt->bind_result($product_id, $product_name, $price, $product_path, $description, $is_featured, $category);
            while ($stmt->fetch()) {
                // Check if this product is being edited
                if (isset($_GET['edit']) && $_GET['edit'] == $product_id) {
                    // Edit form row
                    echo "<tr><form action='manage_products.php' method='post' enctype='multipart/form-data'>";
                    echo "<td><input type='text' name='edit_product_name' value='" . htmlspecialchars($product_name) . "' required></td>";
                    echo "<td><input type='number' step='0.01' name='edit_price' value='" . htmlspecialchars($price) . "' required></td>";
                    echo "<td>";
                    if ($product_path && file_exists($product_path)) {
                        echo "<img src='" . htmlspecialchars($product_path) . "' width='80' /><br>";
                    }
                    echo "<input type='file' name='edit_product_path' accept='image/*'>";
                    echo "<input type='hidden' name='current_product_path' value='" . htmlspecialchars($product_path) . "'>";
                    echo "</td>";
                    echo "<td><textarea name='edit_description'>" . htmlspecialchars($description) . "</textarea></td>";
                    echo "<td>
                            <input type='hidden' name='edit_product_id' value='" . $product_id . "'>
                            <button type='submit' class='kiosk-btn'>Save</button>
                            <a href='manage_products.php' class='kiosk-btn' style='background:#ccc;color:#333;'>Cancel</a>
                          </td>";
                    echo "</form></tr>";
                } else {
                    // Normal display row
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($product_name) . "</td>";
                    echo "<td>₱" . htmlspecialchars(number_format($price, 2)) . "</td>";
                    echo "<td>";
                    if ($product_path && file_exists($product_path)) {
                        echo "<img src='" . htmlspecialchars($product_path) . "' width='80' />";
                    } else {
                        echo "No image";
                    }
                    echo "</td>";
                    echo "<td>" . nl2br(htmlspecialchars($description)) . "</td>";
                    echo "<td>" . htmlspecialchars($category) . "</td>";
                    echo "<td>" . ($is_featured ? "Yes" : "No") . "</td>";
                    echo "<td>
                            <a href='manage_products.php?edit=$product_id' class='kiosk-btn' style='padding:6px 14px;font-size:0.95em;'>Edit</a> 
                            <a href='manage_products.php?delete=$product_id' class='kiosk-btn' style='background:#ff4d4d;padding:6px 14px;font-size:0.95em;' onclick=\"return confirm('Are you sure you want to delete this product?');\">Delete</a>";
                    if ($is_featured) {
                        echo " <a href='manage_products.php?unpublish=$product_id' class='kiosk-btn' style='background:#ccc;color:#333;padding:6px 14px;font-size:0.95em;'>Unpublish</a>";
                    } else {
                        echo " <a href='manage_products.php?publish=$product_id' class='kiosk-btn' style='background:#4caf50;padding:6px 14px;font-size:0.95em;'>Publish</a>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
            }
            $stmt->close();
            $conn->close();
        }
        ?>
    </table>
</div>
<script>
function addProduct() {
    var div = document.createElement('div');
    div.className = 'product-entry';
    div.innerHTML = `
        <input type="text" name="product_name[]" placeholder="Product Name" required>
        <input type="number" step="0.01" name="price[]" placeholder="Price" required>
        <label class="file-label">
            Choose Image
            <input type="file" name="product_path[]" accept="image/*" onchange="showFileName(this)">
        </label>
        <span class="file-name"></span>
        <textarea name="description[]" placeholder="Description"></textarea>
        <select name="category[]" required>
            <option value="">Select Category</option>
            <option value="Beverages">Beverages</option>
            <option value="Snacks">Snacks</option>
            <option value="Meals">Meals</option>
            <option value="Desserts">Desserts</option>
        </select>
        <button type="button" class="kiosk-btn" style="background:#ff4d4d;" onclick="removeProduct(this)">Remove</button>
    `;
    document.getElementById('products').appendChild(div);
}

function removeProduct(btn) {
    btn.parentNode.remove();
}

function showFileName(input) {
    var span = input.parentNode.nextElementSibling;
    if (input.files.length > 0) {
        span.textContent = input.files[0].name;
    } else {
        span.textContent = "";
    }
}
</script>
</body>
</html>