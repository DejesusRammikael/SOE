<?php
session_start();
require_once 'function.php';

$register_message = ""; 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $stall_name = $_POST['stall_name'];
    $phone_number = $_POST['phone_number'];

    // Handle resume file upload
    $resume_path = "";
    if (isset($_FILES['resume']) && $_FILES['resume']['error'] == UPLOAD_ERR_OK) {
        $resume_dir = "uploads/resumes/";
        if (!is_dir($resume_dir)) {
            mkdir($resume_dir, 0777, true);
        }
        $resume_path = $resume_dir . basename($_FILES['resume']['name']);
        move_uploaded_file($_FILES['resume']['tmp_name'], $resume_path);
    }

    // Handle stall photo upload
    $stall_filepath = "";
    if (isset($_FILES['stall_photo']) && $_FILES['stall_photo']['error'] == UPLOAD_ERR_OK) {
        $stall_dir = "uploads/stalls/";
        if (!is_dir($stall_dir)) {
            mkdir($stall_dir, 0777, true);
        }
        $stall_filepath = $stall_dir . basename($_FILES['stall_photo']['name']);
        move_uploaded_file($_FILES['stall_photo']['tmp_name'], $stall_filepath);
    }

    if ($password !== $confirm_password) {
        $register_message = "<div class='alert error'>Passwords do not match!</div>";
    } else {
        $success = register_seller_and_stall(
            $first_name,
            $middle_name,
            $last_name,
            $email,
            $password,
            $resume_path,
            $stall_name,
            $stall_filepath,
            $phone_number
        );
        if ($success) {
            // Get the seller_id and stall_id from the database
            $conn2 = new mysqli("localhost", "root", "", "ezorderdb");
            $stmt = $conn2->prepare("SELECT id FROM seller WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->bind_result($seller_id);
            $stmt->fetch();
            $stmt->close();

            $stmt2 = $conn2->prepare("SELECT stall_id FROM stall WHERE id = ?");
            $stmt2->bind_param("i", $seller_id);
            $stmt2->execute();
            $stmt2->bind_result($stall_id);
            $stmt2->fetch();
            $stmt2->close();
            $conn2->close();

            $_SESSION['seller_id'] = $seller_id;
            $_SESSION['stall_id'] = $stall_id;
            // Check status
            $conn2 = new mysqli("localhost", "root", "", "ezorderdb");
            $stmt = $conn2->prepare("SELECT status FROM seller WHERE id = ?");
            $stmt->bind_param("i", $seller_id);
            $stmt->execute();
            $stmt->bind_result($status);
            $stmt->fetch();
            $stmt->close();
            $conn2->close();
            if ($status === 'approved') {
                header("Location: dashboard.php");
            } else {
                header("Location: wait.php");
            }
            exit();
        } else {
            $register_message = "<div class='alert error'>Registration failed!</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Seller Registration</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="auth-style.css">
</head>
<body>
    <div class="login-card">
        <h1>Register Seller & Stall</h1>
        <?php echo $register_message; ?>
        <form action="register.php" method="post" enctype="multipart/form-data" style="width:100%;">
            <label for="first_name">First Name</label>
            <input type="text" id="first_name" name="first_name" required>
            <label for="middle_name">Middle Name</label>
            <input type="text" id="middle_name" name="middle_name">
            <label for="last_name">Last Name</label>
            <input type="text" id="last_name" name="last_name" required>
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <label for="resume">Resume (PDF)</label>
            <input type="file" id="resume" name="resume" accept=".pdf">
            <hr>
            <label for="stall_name">Stall Name</label>
            <input type="text" id="stall_name" name="stall_name" required>
            <label for="stall_photo">Stall Photo</label>
            <input type="file" id="stall_photo" name="stall_photo" accept="image/*">
            <label for="phone_number">Phone Number</label>
            <input type="text" id="phone_number" name="phone_number" pattern="[0-9]{10,15}" required>
            <button type="submit" name="register">Register</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="adminlogin.php">Login here</a>
        </div>
    </div>
</body>
</html>