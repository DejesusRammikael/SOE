<?php
// Check for cookies if session is not set
if (!isset($_SESSION['seller_id']) && isset($_COOKIE['seller_id'])) {
    $_SESSION['seller_id'] = $_COOKIE['seller_id'];
}
if (!isset($_SESSION['stall_id']) && isset($_COOKIE['stall_id'])) {
    $_SESSION['stall_id'] = $_COOKIE['stall_id'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ezorder Dashboard</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700,400&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Montserrat', Arial, sans-serif;
            background: #f4f6fb;
        }
        .sidebar {
            width: 260px;
            background: linear-gradient(135deg, #ffb347 0%, #ffcc33 100%);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.08);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 40px;
        }
        .sidebar h2 {
            color: #fff;
            margin-bottom: 40px;
            font-size: 2em;
            letter-spacing: 2px;
            font-weight: 700;
            text-shadow: 1px 2px 8px #e6a700;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            width: 100%;
        }
        .sidebar ul li {
            width: 100%;
        }
        .sidebar ul li a {
            display: block;
            padding: 18px 30px;
            color: #fff;
            text-decoration: none;
            font-size: 1.1em;
            font-weight: 500;
            border-left: 5px solid transparent;
            transition: background 0.2s, border-color 0.2s;
        }
        .sidebar ul li a:hover, .sidebar ul li a.active {
            background: rgba(255,255,255,0.18);
            border-left: 5px solid #fff;
        }
        .main-content {
            margin-left: 260px;
            padding: 50px 40px;
            min-height: 100vh;
        }
        h1 {
            font-size: 2.5em;
            color: #ffb347;
            margin-bottom: 20px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .kiosk-cards {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
            margin-top: 30px;
        }
        .kiosk-card {
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.07);
            padding: 32px 28px;
            flex: 1 1 220px;
            min-width: 220px;
            max-width: 320px;
            display: flex;
            flex-direction: column;
            align-items: center;
            transition: transform 0.18s;
        }
        .kiosk-card:hover {
            transform: translateY(-8px) scale(1.03);
            box-shadow: 0 8px 32px rgba(255, 204, 51, 0.18);
        }
        .kiosk-card img {
            width: 60px;
            margin-bottom: 18px;
        }
        .kiosk-card h3 {
            margin: 0 0 10px 0;
            color: #ffb347;
            font-size: 1.3em;
            font-weight: 600;
        }
        .kiosk-card p {
            color: #888;
            font-size: 1em;
            text-align: center;
        }
        @media (max-width: 900px) {
            .main-content {
                padding: 30px 10px;
            }
            .kiosk-cards {
                flex-direction: column;
                gap: 18px;
            }
        }
    </style>
</head>
<body>
<div class="sidebar">
    <h2>Ezorder</h2>
    <ul>
        <li><a href="dashboard.php" class="active">Dashboard</a></li>
        <li><a href="manage_orders.php">Manage Transactions</a></li>
        <li><a href="manage_products.php">Manage Products</a></li>
        <li><a href="feedback.php">Feedback</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
<div class="main-content">
    <h1>Welcome to Ezorder Kiosk</h1>
    <div class="kiosk-cards">
        <div class="kiosk-card">
            <img src="https://img.icons8.com/fluency/96/000000/order-history.png" alt="Transactions">
            <h3>Manage Transactions</h3>
            <p>View and process all your customer orders and sales in one place.</p>
            <a href="manage_orders.php" style="margin-top:12px;color:#ffb347;font-weight:600;text-decoration:underline;">Go</a>
        </div>
        <div class="kiosk-card">
            <img src="https://img.icons8.com/fluency/96/000000/product.png" alt="Products">
            <h3>Manage Products</h3>
            <p>Add, edit, or remove your stall's products and keep your menu up to date.</p>
            <a href="manage_products.php" style="margin-top:12px;color:#ffb347;font-weight:600;text-decoration:underline;">Go</a>
        </div>
        <div class="kiosk-card">
            <img src="https://img.icons8.com/fluency/96/000000/feedback.png" alt="Feedback">
            <h3>Feedback</h3>
            <p>Read customer feedback and improve your service experience.</p>
            <a href="feedback.php" style="margin-top:12px;color:#ffb347;font-weight:600;text-decoration:underline;">Go</a>
        </div>
    </div>
</div>
</body>
</html>