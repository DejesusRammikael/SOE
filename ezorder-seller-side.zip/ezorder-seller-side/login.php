<!DOCTYPE html>
<html>
<head>
    <title>Sign In on Ezorder</title>
</head>
<body>
<h1>Sign In</h1>
<?php
session_start();
require_once 'function.php';
$login_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['email'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    if (seller_login($username, $password, $remember)) {
        header("Location: dashboard.php");
        exit();
    } else {
        $login_message = "<div class='alert error'>Invalid username or password!</div>";
    }
}
if ($login_message) {
    echo $login_message;
}
?>
<form action="login.php" method="post">
    <label for="email">Username:</label>
    <input type="text" id="email" name="email" required><br><br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required><br><br>
    <input type="checkbox" id="remember" name="remember">
    <label for="remember">Remember me</label><br><br>
    <button type="submit">Sign In</button>
    <p>Don't have an account? <a href="register.php">Register here</a></p>
</form>
</body>
</html><?php
function login_admin($username, $password, $remember) {
    return seller_login($username, $password, $remember);
}
?>