<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once 'database.php';

// Check for cookies if session is not set
if (!isset($_SESSION['seller_id']) && isset($_COOKIE['seller_id'])) {
    $_SESSION['seller_id'] = $_COOKIE['seller_id'];
}
if (!isset($_SESSION['stall_id']) && isset($_COOKIE['stall_id'])) {
    $_SESSION['stall_id'] = $_COOKIE['stall_id'];
}

// Set default stall_id to 4 if not set
if (!isset($_SESSION['stall_id'])) {
    $_SESSION['stall_id'] = 4;
}

// Get stall ID from session
$stall_id = $_SESSION['stall_id'];

try {
    $query = "SELECT * FROM ratings ORDER BY created_at ASC";
    $result = $conn->query($query);
    
    $avg_query = "SELECT AVG(rating) as avg_rating, COUNT(*) as total_ratings FROM ratings";
    $avg_result = $conn->query($avg_query);
    $rating_stats = $avg_result->fetch_assoc();
    
} catch (Exception $e) {
    $error = "An error occurred while fetching the feedback: " . $e->getMessage();
}

// Debug session
echo "<!-- Session stall_id: " . ($_SESSION['stall_id'] ?? 'not set') . " -->";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ezorder Feedback</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700,400&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Montserrat', Arial, sans-serif;
            background: #f4f6fb;
        }
        .sidebar {
            width: 260px;
            background: linear-gradient(135deg, #ffb347 0%, #ffcc33 100%);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.08);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 40px;
        }
        .sidebar h2 {
            color: #fff;
            margin-bottom: 40px;
            font-size: 2em;
            letter-spacing: 2px;
            font-weight: 700;
            text-shadow: 1px 2px 8px #e6a700;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            width: 100%;
        }
        .sidebar ul li {
            width: 100%;
        }
        .sidebar ul li a {
            display: block;
            padding: 18px 30px;
            color: #fff;
            text-decoration: none;
            font-size: 1.1em;
            font-weight: 500;
            border-left: 5px solid transparent;
            transition: background 0.2s, border-color 0.2s;
        }
        .sidebar ul li a:hover, .sidebar ul li a.active {
            background: rgba(255,255,255,0.18);
            border-left: 5px solid #fff;
        }
        .main-content {
            margin-left: 260px;
            padding: 50px 40px;
            min-height: 100vh;
        }
        h1 {
            font-size: 2.5em;
            color: #ffb347;
            margin-bottom: 20px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .stats-card {
            background: #fff;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .stats-card h3 {
            color: #ffb347;
            margin: 0 0 15px 0;
        }
        .feedback-list {
            display: grid;
            gap: 20px;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        }
        .feedback-card {
            background: #fff;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .feedback-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        .username {
            font-weight: 600;
            color: #333;
        }
        .rating {
            color: #ffb347;
            font-weight: bold;
        }
        .comment {
            color: #555;
            line-height: 1.5;
            margin: 10px 0;
        }
        .date {
            color: #888;
            font-size: 0.9em;
        }
        .stars {
            color: #ffb347;
            font-size: 1.2em;
        }
        @media (max-width: 900px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            .sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Ezorder</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage_orders.php">Manage Transactions</a></li>
            <li><a href="manage_products.php">Manage Products</a></li>
            <li><a href="feedback.php" class="active">Feedback</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h1>Customer Feedback</h1>
        
        <?php if (isset($error)): ?>
            <div style="color: red; margin-bottom: 20px;"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="stats-card">
            <h3>Rating Overview</h3>
            <p>Average Rating: <span class="stars">
                <?php 
                $avg_rating = $rating_stats['avg_rating'];
                if ($avg_rating > 0) {
                    echo str_repeat('★', floor($avg_rating));
                    echo str_repeat('☆', 5 - floor($avg_rating));
                    echo ' (' . number_format($avg_rating, 1) . ')';
                } else {
                    echo '☆☆☆☆☆ (No ratings yet)';
                }
                ?>
                </span>
            </p>
            <p>Total Reviews: <?php echo $rating_stats['total_ratings']; ?></p>
        </div>

        <div class="feedback-list">
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="feedback-card">
                        <div class="feedback-header">
                            <span class="username"><?php echo htmlspecialchars($row['username']); ?></span>
                            <span class="rating">
                                <?php echo str_repeat('★', intval($row['rating'])) . str_repeat('☆', 5 - intval($row['rating'])); ?>
                            </span>
                        </div>
                        <?php if (isset($row['comment']) && !empty($row['comment'])): ?>
                            <p class="comment"><?php echo htmlspecialchars($row['comment']); ?></p>
                        <?php endif; ?>
                        <div class="date">
                            <?php echo date('F j, Y g:i A', strtotime($row['created_at'])); ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="text-align: center; color: #888; margin-top: 50px;">No feedback found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html> 